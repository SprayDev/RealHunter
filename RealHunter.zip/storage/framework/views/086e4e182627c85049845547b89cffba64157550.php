<hunter-footer></hunter-footer>
<?php echo $__env->make('partials.footer.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH D:\server\OSPanel\domains\RealHunter\resources\views/partials/footer/footer.blade.php ENDPATH**/ ?>