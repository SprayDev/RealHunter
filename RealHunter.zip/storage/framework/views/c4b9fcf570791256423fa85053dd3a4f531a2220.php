<?php $__env->startSection('page'); ?>
<hunter-perms-post :perms="<?php echo e(json_encode($perms)); ?>"></hunter-perms-post>
<div class="container w-100 border">

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\OSPanel\domains\RealHunter\resources\views/pages/permissions.blade.php ENDPATH**/ ?>