<?php $__env->startSection('page'); ?>
    <div class="container mb-5">
        <h1 class="hunter-perm-title">Разрешение на охоту: <span><?php echo e($perm->title); ?></span></h1>
        <div class="row px-0">
            <div class="col-lg-8 col-md-10 frame_container" style="height: 400px">
                <?php echo $perm->map_frame; ?>

            </div>
            <div class="col-lg-4 col-md-2">
                <div class="card mb-3 border-0" style="background: #F5F5F5;">
                    <div class="card-body">
                        <h5 class="card-title font-weight-bolder">Сезон охоты</h5>
                        <p class="card-text"><?php echo e(date('d.m.Y', strtotime($perm->seasons[0]->date_from))); ?> - <?php echo e(date('d.m.Y', strtotime($perm->seasons[0]->date_to))); ?></p>
                        <h5 class="card-title font-weight-bolder">Место</h5>
                        <p class="card-text"><?php echo e($perm->location->title); ?></p>
                        <h5 class="card-title font-weight-bolder">Стоимость лицензии</h5>
                        <p class="card-text font-weight-bold hunter-text-green">от <?php echo e($perm->price_full); ?> руб</p>
                    </div>
                </div>
                <a class="btn ml-auto hunter-start-hunt-btn hunter-border-orange hunter-text-orange w-100" href="#" data-toggle="modal" data-target="#permModal">Получить разрешение</a>
            </div>
        </div>
        <h1 class="font-weight-bold mt-4">Туры</h1>
        <?php $__currentLoopData = $tours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tour): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row px-0 pt-4">
                <div class="col-7 d-flex align-items-center">
                    <p><?php echo e($tour->title); ?></p>
                </div>
                <div class="col-2 d-flex align-items-center">
                    <h4 class="hunter-perm-title"><span><?php echo e($tour->price_full); ?> руб</span></h4>
                </div>
                <div class="col-3 d-flex">
                    <a class="btn ml-auto hunter-start-hunt-btn hunter-border-orange hunter-text-orange" href="/tours/<?php echo e($tour->id); ?>">Посмотреть туры</a>
                </div>
                <div class="w-75 border mb-3"></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <hunter-perm-modal :license="<?php echo e(json_encode($perm)); ?>"></hunter-perm-modal>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\OSPanel\domains\RealHunter\resources\views/pages/permission.blade.php ENDPATH**/ ?>