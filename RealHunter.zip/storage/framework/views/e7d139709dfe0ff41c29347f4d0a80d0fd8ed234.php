<?php $__env->startSection('page'); ?>
    <hunter-page-tour :tour="<?php echo e(json_encode($tour)); ?>" days="<?php echo e($days); ?>" :tours="<?php echo e(json_encode($tours)); ?>"></hunter-page-tour>
    <div class="container w-100 border">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\OSPanel\domains\RealHunter\resources\views/pages/tour.blade.php ENDPATH**/ ?>