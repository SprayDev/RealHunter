<?php echo $__env->yieldPushContent('scripts'); ?>
<?php /**PATH D:\server\OSPanel\domains\RealHunter\resources\views/partials/footer/scripts.blade.php ENDPATH**/ ?>