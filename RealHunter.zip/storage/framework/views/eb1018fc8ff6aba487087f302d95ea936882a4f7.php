<hunter-header url="<?php echo e(Request::url()); ?>"></hunter-header>
<?php /**PATH D:\server\OSPanel\domains\RealHunter\resources\views/partials/header.blade.php ENDPATH**/ ?>