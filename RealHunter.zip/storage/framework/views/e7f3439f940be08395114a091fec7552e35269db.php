<?php $__env->startSection('page'); ?>
    <hunter-page-post :blog="<?php echo e(json_encode($blog)); ?>"></hunter-page-post>
    <div class="container w-100 border">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\OSPanel\domains\RealHunter\resources\views/pages/post.blade.php ENDPATH**/ ?>