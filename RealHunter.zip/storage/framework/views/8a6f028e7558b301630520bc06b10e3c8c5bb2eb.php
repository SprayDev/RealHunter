<?php $__env->startSection('page'); ?>
    <div class="container my-5">
        <hunter-page-blog :blogs="<?php echo e(json_encode($blogs)); ?>"></hunter-page-blog>
    </div>
    <div class="container w-100 border">
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\server\OSPanel\domains\RealHunter\resources\views/pages/blog.blade.php ENDPATH**/ ?>