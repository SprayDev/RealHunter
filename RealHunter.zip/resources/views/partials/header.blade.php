<hunter-header url="{{Request::url()}}"></hunter-header>
